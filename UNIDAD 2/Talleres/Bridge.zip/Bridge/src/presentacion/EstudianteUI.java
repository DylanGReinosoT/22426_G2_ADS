package presentacion;

import abstraccion.EstudianteGestor;
import modelo.Estudiante;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

// Clase que maneja la interfaz de usuario para la gestión de estudiantes
public class EstudianteUI {

    // Objeto gestor que maneja las operaciones con estudiantes (abstracción)
    private final EstudianteGestor gestor;
    // Scanner para leer la entrada del usuario desde consola
    private final Scanner scanner = new Scanner(System.in);

    // Constructor que recibe un gestor de estudiantes
    public EstudianteUI(EstudianteGestor gestor) {
        this.gestor = gestor;
    }

    // Método principal que inicia el menú interactivo en consola
    public void iniciar() {
        while (true) {
            // Mostrar las opciones del menú
            System.out.println("\n=== Gestión de Estudiantes ===");
            System.out.println("1. Agregar Estudiante");
            System.out.println("2. Listar Estudiantes");
            System.out.println("3. Buscar Estudiante");
            System.out.println("4. Actualizar Estudiante");
            System.out.println("5. Eliminar Estudiante");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            // Leer la opción elegida por el usuario
            int opcion = Integer.parseInt(scanner.nextLine());

            // Ejecutar la acción según la opción elegida
            switch (opcion) {
                case 1 -> agregarEstudiante();      // Llamar al método para agregar
                case 2 -> listarEstudiantes();      // Listar todos los estudiantes
                case 3 -> buscarEstudiante();       // Buscar un estudiante por ID
                case 4 -> actualizarEstudiante();   // Actualizar datos de un estudiante
                case 5 -> eliminarEstudiante();     // Eliminar un estudiante por ID
                case 6 -> {
                    System.out.println("¡Hasta luego!"); // Mensaje de despedida
                    return;  // Salir del método (termina el programa)
                }
                default -> System.out.println("Opción no válida."); // Mensaje para opción incorrecta
            }
        }
    }

    // Método para agregar un estudiante leyendo datos desde consola
    private void agregarEstudiante() {
        System.out.print("ID: ");
        int id = Integer.parseInt(scanner.nextLine());
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = Integer.parseInt(scanner.nextLine());
        gestor.crearEstudiante(id, nombre, edad);  // Usar el gestor para crear el estudiante
        System.out.println("Estudiante agregado.");
    }

    // Método para listar todos los estudiantes y mostrarlos por consola
    private void listarEstudiantes() {
        List<Estudiante> lista = gestor.listarEstudiantes();
        if (lista.isEmpty()) {
            System.out.println("No hay estudiantes.");
        } else {
            lista.forEach(System.out::println);  // Imprimir cada estudiante
        }
    }

    // Método para buscar un estudiante por ID y mostrar el resultado
    private void buscarEstudiante() {
        System.out.print("ID: ");
        int id = Integer.parseInt(scanner.nextLine());
        Optional<Estudiante> estudiante = gestor.buscarEstudiante(id);
        estudiante.ifPresentOrElse(
                System.out::println,                     // Si está presente, imprimir
                () -> System.out.println("Estudiante no encontrado.")  // Si no, mostrar mensaje
        );
    }

    // Método para actualizar un estudiante, leyendo los nuevos datos
    private void actualizarEstudiante() {
        System.out.print("ID: ");
        int id = Integer.parseInt(scanner.nextLine());
        System.out.print("Nuevo nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Nueva edad: ");
        int edad = Integer.parseInt(scanner.nextLine());
        if (gestor.actualizarEstudiante(id, nombre, edad)) {
            System.out.println("Estudiante actualizado.");
        } else {
            System.out.println("Estudiante no encontrado.");
        }
    }

    // Método para eliminar un estudiante por ID
    private void eliminarEstudiante() {
        System.out.print("ID: ");
        int id = Integer.parseInt(scanner.nextLine());
        if (gestor.eliminarEstudiante(id)) {
            System.out.println("Estudiante eliminado.");
        } else {
            System.out.println("Estudiante no encontrado.");
        }
    }
}


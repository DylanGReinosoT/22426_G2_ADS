import abstraccion.EstudianteGestor;
import abstraccion.EstudianteGestorBasico;
import implementacion.EstudianteAlmacenamientoMemoria;
import presentacion.EstudianteUI;

// Clase principal que inicia la aplicación
public class Main {
    public static void main(String[] args) {
        // Se crea un gestor básico de estudiantes, inyectándole el almacenamiento en memoria
        EstudianteGestor gestor = new EstudianteGestorBasico(
                new EstudianteAlmacenamientoMemoria()
        );

        // Se crea la interfaz de usuario, pasándole el gestor creado
        EstudianteUI ui = new EstudianteUI(gestor);

        // Se arranca la interfaz de usuario para que interactúe con el usuario por consola
        ui.iniciar();
    }
}

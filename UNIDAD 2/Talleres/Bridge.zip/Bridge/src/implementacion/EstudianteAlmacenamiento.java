// Paquete que contiene las clases relacionadas con la implementación
package implementacion;

// Importa la clase Estudiante del modelo de datos
import modelo.Estudiante;

import java.util.List;
import java.util.Optional;

// Interfaz que define las operaciones básicas para el almacenamiento de estudiantes
public interface EstudianteAlmacenamiento {

    // Método para agregar un nuevo estudiante al almacenamiento
    void agregar(Estudiante estudiante);

    // Método para obtener la lista completa de estudiantes almacenados
    List<Estudiante> obtenerTodos();

    // Método para buscar un estudiante por su ID, devuelve un Optional que puede contener o no el estudiante
    Optional<Estudiante> buscarPorId(int id);

    // Método para actualizar un estudiante existente, devuelve true si la actualización fue exitosa
    boolean actualizar(int id, String nombre, int edad);

    // Método para eliminar un estudiante por su ID, devuelve true si la eliminación fue exitosa
    boolean eliminar(int id);
}


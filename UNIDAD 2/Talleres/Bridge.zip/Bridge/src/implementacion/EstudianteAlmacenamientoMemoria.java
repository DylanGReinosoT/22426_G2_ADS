package implementacion;

import modelo.Estudiante;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

// Clase que implementa el almacenamiento de estudiantes usando una lista en memoria
public class EstudianteAlmacenamientoMemoria implements EstudianteAlmacenamiento {

    // Lista que almacena los objetos Estudiante
    private final List<Estudiante> estudiantes = new ArrayList<>();

    // Método para agregar un estudiante a la lista
    @Override
    public void agregar(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    // Método que devuelve una copia de la lista con todos los estudiantes
    @Override
    public List<Estudiante> obtenerTodos() {
        return new ArrayList<>(estudiantes);
    }

    // Método para buscar un estudiante por su ID usando Stream y filtro
    @Override
    public Optional<Estudiante> buscarPorId(int id) {
        return estudiantes.stream()
                .filter(e -> e.getId() == id) // filtra por ID
                .findFirst(); // devuelve el primero que coincida, si existe
    }

    // Método para actualizar el nombre y la edad de un estudiante dado su ID
    @Override
    public boolean actualizar(int id, String nombre, int edad) {
        Optional<Estudiante> estudiante = buscarPorId(id);
        if (estudiante.isPresent()) {
            estudiante.get().setNombre(nombre);
            estudiante.get().setEdad(edad);
            return true; // actualización exitosa
        }
        return false; // estudiante no encontrado
    }

    // Método para eliminar un estudiante por su ID usando removeIf
    @Override
    public boolean eliminar(int id) {
        return estudiantes.removeIf(e -> e.getId() == id);
    }
}

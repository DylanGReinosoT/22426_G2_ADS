// Paquete que contiene las clases relacionadas con la abstracción
package abstraccion;

// Importa la clase que define cómo se almacenan los estudiantes
import implementacion.EstudianteAlmacenamiento;

// Importa la clase Estudiante y utilidades para trabajar con listas y valores opcionales
import modelo.Estudiante;
import java.util.List;
import java.util.Optional;

// Clase abstracta que define la interfaz (abstracción) para gestionar estudiantes
public abstract class EstudianteGestor {

    // Referencia protegida al almacenamiento (implementación) de los estudiantes
    protected EstudianteAlmacenamiento almacenamiento;

    // Constructor que recibe un objeto de almacenamiento y lo asigna al atributo
    public EstudianteGestor(EstudianteAlmacenamiento almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    // Método abstracto para crear un estudiante (debe implementarse en una subclase)
    public abstract void crearEstudiante(int id, String nombre, int edad);

    // Método abstracto para obtener una lista de todos los estudiantes
    public abstract List<Estudiante> listarEstudiantes();

    // Método abstracto para buscar un estudiante por ID, devuelve un Optional
    public abstract Optional<Estudiante> buscarEstudiante(int id);

    // Método abstracto para actualizar los datos de un estudiante, devuelve true si tuvo éxito
    public abstract boolean actualizarEstudiante(int id, String nombre, int edad);

    // Método abstracto para eliminar un estudiante por ID, devuelve true si fue eliminado
    public abstract boolean eliminarEstudiante(int id);
}

// Paquete que contiene las clases relacionadas con la abstracción
package abstraccion;

// Importa la clase Estudiante del modelo de datos
import modelo.Estudiante;
// Importa la clase que maneja el almacenamiento de estudiantes
import implementacion.EstudianteAlmacenamiento;

import java.util.List;
import java.util.Optional;

// Clase concreta que extiende la clase abstracta EstudianteGestor
// Implementa los métodos para gestionar estudiantes utilizando un almacenamiento concreto
public class EstudianteGestorBasico extends EstudianteGestor {

    // Constructor que recibe una implementación de almacenamiento y la pasa a la clase padre
    public EstudianteGestorBasico(EstudianteAlmacenamiento almacenamiento) {
        super(almacenamiento);
    }

    // Método para crear un nuevo estudiante y agregarlo al almacenamiento
    @Override
    public void crearEstudiante(int id, String nombre, int edad) {
        almacenamiento.agregar(new Estudiante(id, nombre, edad));
    }

    // Método que devuelve la lista completa de estudiantes almacenados
    @Override
    public List<Estudiante> listarEstudiantes() {
        return almacenamiento.obtenerTodos();
    }

    // Método que busca un estudiante por su id y devuelve un Optional con el resultado
    @Override
    public Optional<Estudiante> buscarEstudiante(int id) {
        return almacenamiento.buscarPorId(id);
    }

    // Método que actualiza los datos de un estudiante y devuelve true si la operación fue exitosa
    @Override
    public boolean actualizarEstudiante(int id, String nombre, int edad) {
        return almacenamiento.actualizar(id, nombre, edad);
    }

    // Método que elimina un estudiante por su id y devuelve true si se eliminó correctamente
    @Override
    public boolean eliminarEstudiante(int id) {
        return almacenamiento.eliminar(id);
    }
}


// Paquete que contiene la clase modelo Estudiante
package modelo;

// Clase que representa un estudiante con id, nombre y edad
public class Estudiante {
    // Atributo para el identificador del estudiante
    private int id;
    // Atributo para el nombre del estudiante
    private String nombre;
    // Atributo para la edad del estudiante
    private int edad;

    // Constructor que inicializa el estudiante con id, nombre y edad
    public Estudiante(int id, String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    // Método getter para obtener el id
    public int getId() {
        return id;
    }

    // Método setter para asignar el id
    public void setId(int id) {
        this.id = id;
    }

    // Método getter para obtener el nombre
    public String getNombre() {
        return nombre;
    }

    // Método setter para asignar el nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Método getter para obtener la edad
    public int getEdad() {
        return edad;
    }

    // Método setter para asignar la edad
    public void setEdad(int edad) {
        this.edad = edad;
    }

    // Método toString para mostrar la información del estudiante como texto
    @Override
    public String toString() {
        return "Estudiante{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                '}';
    }
}


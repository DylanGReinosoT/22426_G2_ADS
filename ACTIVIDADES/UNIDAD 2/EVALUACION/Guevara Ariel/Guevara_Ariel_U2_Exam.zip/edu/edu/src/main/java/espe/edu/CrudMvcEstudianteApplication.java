package espe.edu;

import espe.edu.ui.Main;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.swing.*;
import javax.swing.SwingUtilities;
@SpringBootApplication
public class CrudMvcEstudianteApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudMvcEstudianteApplication.class, args);
		System.out.println("Aplicación de gestión de estudiantes iniciada correctamente.");
		SwingUtilities.invokeLater(Main::crearVentana);

	}

}

package espe.edu.model;

/**
 * Clase que representa a un estudiante con sus datos básicos.
 */
public class Estudiante {
    // Identificador único del estudiante
    private int id;
    // Apellidos del estudiante
    private String apellidos;
    // Nombres del estudiante
    private String nombres;
    // Edad del estudiante
    private int edad;

    /**
     * Constructor para crear un estudiante con todos sus datos.
     * @param id ID del estudiante
     * @param apellidos Apellidos del estudiante
     * @param nombres Nombres del estudiante
     * @param edad Edad del estudiante
     */
    public Estudiante(int id, String apellidos, String nombres, int edad) {
        this.id = id;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.edad = edad;
    }

    // Getters y Setters
    /**
     * Obtiene el ID del estudiante.
     */
    public int getId() { return id; }
    /**
     * Establece el ID del estudiante.
     */
    public void setId(int id) { this.id = id; }
    /**
     * Obtiene los apellidos del estudiante.
     */
    public String getApellidos() { return apellidos; }
    /**
     * Establece los apellidos del estudiante.
     */
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }
    /**
     * Obtiene los nombres del estudiante.
     */
    public String getNombres() { return nombres; }
    /**
     * Establece los nombres del estudiante.
     */
    public void setNombres(String nombres) { this.nombres = nombres; }
    /**
     * Obtiene la edad del estudiante.
     */
    public int getEdad() { return edad; }
    /**
     * Establece la edad del estudiante.
     */
    public void setEdad(int edad) { this.edad = edad; }

}

package espe.edu.ui;

import espe.edu.controller.EstudianteController;
import espe.edu.model.Estudiante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

/**
 * Clase principal que inicia la aplicación de gestión de estudiantes usando Swing.
 * Crea la ventana principal y los componentes de la interfaz gráfica.
 */
public class Main {
    /**
     * Metodo principal que inicia la aplicación en el hilo de eventos de Swing.
     * @param args Argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::crearVentana);
        // Se crea un controlador de estudiantes (no utilizado aquí)
        EstudianteController controller = new EstudianteController();


    }

    /**
     * Crea y muestra la ventana principal de la aplicación.
     * Configura el JFrame, el panel y los campos de texto.
     */
    public static void crearVentana() {
        JFrame frame = new JFrame("Estudiantes MVC");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        // Controlador para manejar la lógica de estudiantes
        EstudianteController controller = new EstudianteController();

        // Se agregan estudiantes de ejemplo
        controller.crearEstudiante(1, "Pérez", "Ana", 20);
        controller.crearEstudiante(2, "García", "Luis", 22);

        // Panel principal con layout de cuadrícula
        JPanel panel = new JPanel(new GridLayout(9, 2));
        // Campos de texto para ingresar datos del estudiante
        JTextField idField = new JTextField();
        JTextField nombresField = new JTextField();
        JTextField apellidosField = new JTextField();
        JTextField edadField = new JTextField();

        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Nombres:"));
        panel.add(nombresField);
        panel.add(new JLabel("Apellidos:"));
        panel.add(apellidosField);
        panel.add(new JLabel("Edad:"));
        panel.add(edadField);

        // Botones para las acciones de CRUD
        JButton agregarBtn = new JButton("Agregar");
        JButton eliminarBtn = new JButton("Eliminar");
        JButton actualizarBtn = new JButton("Actualizar");
        JButton buscarBtn = new JButton("Buscar");
        JButton limpiarBtn = new JButton("Limpiar");
        panel.add(agregarBtn);
        panel.add(eliminarBtn);
        panel.add(actualizarBtn);
        panel.add(buscarBtn);
        panel.add(limpiarBtn);

        // Tabla
        String[] columnas = {"ID", "Nombres", "Apellidos", "Edad"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);
        JTable tabla = new JTable(modelo);
        JScrollPane scrollPane = new JScrollPane(tabla);

        // Se actualiza la tabla con los estudiantes existentes
        actualizarTabla(modelo, controller.obtenerTodos());
        // Acción botón agregar
        agregarBtn.addActionListener((ActionEvent e) -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String nombres = nombresField.getText();
                String apellidos = apellidosField.getText();
                int edad = Integer.parseInt(edadField.getText());
                // Se verifica si el estudiante ya existe
                if (controller.existeEstudiante(id)){
                    JOptionPane.showMessageDialog(frame, "El estudiante con ID: " + id + " ya existe");
                    return;
                }
                // Se crea un nuevo estudiante
                controller.crearEstudiante(id, apellidos, nombres, edad);
                // Se actualiza la tabla
                actualizarTabla(modelo, controller.obtenerTodos());
                // Se limpian los campos
                idField.setText("");
                nombresField.setText("");
                apellidosField.setText("");
                edadField.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Datos inválidos");
            }
        });

        // boton eliminar Estudiante
        eliminarBtn.addActionListener((ActionEvent e) -> {
            try {
                int id = Integer.parseInt(idField.getText());
                // Se elimina el estudiante por ID
                controller.eliminarEstudiante(id);
                // Se actualiza la tabla
                actualizarTabla(modelo, controller.obtenerTodos());
                // Se limpian los campos
                idField.setText("");
                nombresField.setText("");
                apellidosField.setText("");
                edadField.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "ID inválido");
            }
        });

        // boton Actualizar Estudiante
        actualizarBtn.addActionListener((ActionEvent e) -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String nombres = nombresField.getText();
                String apellidos = apellidosField.getText();
                int edad = Integer.parseInt(edadField.getText());
                // Se verifica si el estudiante existe
                if (!controller.existeEstudiante(id)){
                    JOptionPane.showMessageDialog(frame, "El estudiante con ID: " + id + " no existe");
                    return;
                }
                // Se actualiza la información del estudiante
                controller.actualizarEstudiante(id, apellidos, nombres, edad);
                // Se actualiza la tabla
                actualizarTabla(modelo, controller.obtenerTodos());
                // Se limpian los campos
                idField.setText("");
                nombresField.setText("");
                apellidosField.setText("");
                edadField.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Datos inválidos");
            }
        });

        // boton Buscar Estudiante
        buscarBtn.addActionListener((ActionEvent e) -> {
            try {
                int id = Integer.parseInt(idField.getText());
                // Se busca el estudiante por ID
                Estudiante estudiante = controller.obtenerEstudiantePorId(id);
                if (estudiante != null) {
                    // Se llenan los campos con la información del estudiante
                    idField.setText(String.valueOf(estudiante.getId()));
                    nombresField.setText(estudiante.getNombres());
                    apellidosField.setText(estudiante.getApellidos());
                    edadField.setText(String.valueOf(estudiante.getEdad()));
                } else {
                    JOptionPane.showMessageDialog(frame, "Estudiante no encontrado");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "ID inválido");
            }
        });

        // boton Limpiar campos
        limpiarBtn.addActionListener((ActionEvent e) -> {
            // Se limpian todos los campos
            idField.setText("");
            nombresField.setText("");
            apellidosField.setText("");
            edadField.setText("");
        });

        // Se configura el layout del frame y se añaden los componentes
        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        frame.setVisible(true);
    }

    /**
     * Actualiza la tabla con la lista de estudiantes.
     * @param modelo El modelo de la tabla
     * @param estudiantes La lista de estudiantes a mostrar
     */
    private static void actualizarTabla(DefaultTableModel modelo, List<Estudiante> estudiantes) {
        modelo.setRowCount(0);
        for (Estudiante e : estudiantes) {
            modelo.addRow(new Object[]{e.getId(), e.getNombres(), e.getApellidos(), e.getEdad()});
        }
    }
}
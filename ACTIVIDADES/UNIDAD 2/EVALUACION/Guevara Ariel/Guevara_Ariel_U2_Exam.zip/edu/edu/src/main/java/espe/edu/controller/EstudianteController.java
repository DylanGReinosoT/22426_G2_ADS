package espe.edu.controller;

import espe.edu.dao.EstudianteDAO;
import espe.edu.model.Estudiante;

import java.util.List;

/**
 * Controlador para gestionar las operaciones relacionadas con los estudiantes.
 * Se comunica con el DAO para realizar operaciones CRUD.
 */
public class EstudianteController {
    // Instancia del DAO para acceder a los datos de los estudiantes
    private EstudianteDAO dao = new EstudianteDAO();

    /**
     * Crea un nuevo estudiante y lo agrega a la lista.
     * @param id ID del estudiante
     * @param apellidos Apellidos del estudiante
     * @param nombres Nombres del estudiante
     * @param edad Edad del estudiante
     */
    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        dao.agregar(e);
    }

    /**
     * Obtiene la lista de todos los estudiantes.
     * @return Lista de estudiantes
     */
    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    /**
     * Busca un estudiante por su ID.
     * @param id ID del estudiante
     * @return El estudiante encontrado o null si no existe
     */
    public Estudiante obtenerEstudiantePorId(int id) {
        return dao.buscarPorId(id);
    }
    /**
     * Verifica si un estudiante existe por su ID.
     * @param id ID del estudiante
     * @return true si existe, false si no
     */
    public boolean existeEstudiante(int id) {
        return dao.existe(id);
    }

    /**
     * Elimina un estudiante por su ID.
     * @param id ID del estudiante
     */
    public void eliminarEstudiante(int id) {
        dao.eliminar(id);
    }
    /**
     * Actualiza los datos de un estudiante existente.
     * @param id ID del estudiante
     * @param apellidos Nuevos apellidos
     * @param nombres Nuevos nombres
     * @param edad Nueva edad
     */
    public void actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        dao.actualizar(e);
    }

    /**
     * Busca un estudiante por su ID (método redundante con obtenerEstudiantePorId).
     * @param id ID del estudiante
     * @return El estudiante encontrado o null si no existe
     */
    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }

}

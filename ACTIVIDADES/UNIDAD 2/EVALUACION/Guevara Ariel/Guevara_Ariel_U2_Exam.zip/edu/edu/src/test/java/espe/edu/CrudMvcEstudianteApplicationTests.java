package espe.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudMvcEstudianteApplicationTests {

	@Test
	void contextLoads() {
	}

}

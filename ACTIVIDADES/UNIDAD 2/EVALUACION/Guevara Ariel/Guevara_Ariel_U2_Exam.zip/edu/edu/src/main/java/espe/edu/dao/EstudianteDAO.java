package espe.edu.dao;

import espe.edu.model.Estudiante;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase DAO (Data Access Object) para gestionar la lista de estudiantes en memoria.
 * Proporciona métodos para operaciones CRUD sobre los estudiantes.
 */
public class EstudianteDAO {
    // Lista que almacena los estudiantes en memoria
    private List<Estudiante> estudiantes = new ArrayList<>();

    /**
     * Agrega un estudiante a la lista.
     * @param e Estudiante a agregar
     */
    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }
    /**
     * Verifica si existe un estudiante con el ID dado.
     * @param id ID del estudiante
     * @return true si existe, false si no
     */
    public boolean existe(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return true;
            }
        }
        return false;
    }
    /**
     * Devuelve la lista de todos los estudiantes.
     * @return Lista de estudiantes
     */
    public List<Estudiante> listar() {
        return estudiantes;
    }

    /**
     * Elimina un estudiante por su ID.
     * @param id ID del estudiante a eliminar
     */
    public void eliminar(int id) {
        estudiantes.removeIf(e -> e.getId() == id);
    }
    /**
     * Actualiza los datos de un estudiante existente.
     * @param e Estudiante con los datos actualizados
     */
    public void actualizar(Estudiante e) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == e.getId()) {
                estudiantes.set(i, e);
                return;
            }
        }
    }

    /**
     * Busca un estudiante por su ID.
     * @param id ID del estudiante
     * @return El estudiante encontrado o null si no existe
     */
    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }

}

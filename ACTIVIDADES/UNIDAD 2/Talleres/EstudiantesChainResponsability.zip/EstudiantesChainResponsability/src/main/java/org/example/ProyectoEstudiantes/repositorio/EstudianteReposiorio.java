package org.example.ProyectoEstudiantes.repositorio;

import org.example.ProyectoEstudiantes.modelo.Estudiante;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EstudianteReposiorio {

    private final List<Estudiante> estudiantes = new ArrayList<>();

    /*Este metodo recibe un objeto Estudiante y lo añade a la lista estudiantes.*/

    public void agregar(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public List<Estudiante> obtenerTodos() {
        return new ArrayList<>(estudiantes);
    }

    public Optional<Estudiante> buscarPorId(int id) {
        return estudiantes.stream().filter(e -> e.getId() == id).findFirst();
    }

    public boolean eliminar(int id) {
        return estudiantes.removeIf(e -> e.getId() == id);
    }

}

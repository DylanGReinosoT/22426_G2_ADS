package org.example.ProyectoEstudiantes.servicio.validator;
import org.example.ProyectoEstudiantes.exception.ValidationException;
import org.example.ProyectoEstudiantes.modelo.Estudiante;
import org.example.ProyectoEstudiantes.servicio.validator.AbstractEstudianteValidator;

public class IdValidator extends AbstractEstudianteValidator{
    @Override
    protected void performValidation(Estudiante estudiante) throws ValidationException {
        if (estudiante.getId() <= 0) {
            throw new ValidationException("El ID del estudiante debe ser un número positivo.");
        }
    }
}

package org.example.ProyectoEstudiantes.servicio.validator;
import org.example.ProyectoEstudiantes.exception.ValidationException;
import org.example.ProyectoEstudiantes.modelo.Estudiante;

public interface EstudianteValidator {
    void validate(Estudiante estudiante) throws ValidationException;
    void setNext(EstudianteValidator next);
}

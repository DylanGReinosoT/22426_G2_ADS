package org.example.ProyectoEstudiantes.servicio.validator;
import org.example.ProyectoEstudiantes.exception.ValidationException;
import org.example.ProyectoEstudiantes.modelo.Estudiante;

// Clase abstracta base para validadores de estudiantes usando el patrón Chain of Responsibility
public abstract class AbstractEstudianteValidator implements EstudianteValidator{
    // Referencia al siguiente validador en la cadena
    private EstudianteValidator next;

    @Override
    // Establece el siguiente validador en la cadena
    public void setNext(EstudianteValidator next) {
        this.next = next;
    }
    @Override
    // Ejecuta la validación y pasa al siguiente validador si existe
    public void validate(Estudiante estudiante) throws ValidationException {
        performValidation(estudiante);
        if (next != null) {
            next.validate(estudiante);
        }
    }

    // Método que debe implementar cada validador concreto
    protected abstract void performValidation(Estudiante estudiante) throws ValidationException;

}

package org.example;

import org.example.ProyectoEstudiantes.presentacion.EstudianteUI;

public class Main {
    public static void main(String[] args) {
        // Configuración del look and feel para que se vea nativo en cada SO

        // Iniciar la interfaz de usuario
        EstudianteUI.iniciar();

        // Mensaje de consola para verificar que la cadena de validación está configurada
        System.out.println("Aplicación iniciada. Cadena de validación configurada correctamente.");
    }
}
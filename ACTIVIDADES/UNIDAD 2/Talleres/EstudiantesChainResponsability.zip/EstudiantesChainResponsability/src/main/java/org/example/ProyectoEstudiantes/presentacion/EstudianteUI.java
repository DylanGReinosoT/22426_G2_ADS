package org.example.ProyectoEstudiantes.presentacion;

import org.example.ProyectoEstudiantes.modelo.Estudiante;
import org.example.ProyectoEstudiantes.servicio.EstudianteServicio;
import org.example.ProyectoEstudiantes.exception.ValidationException;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Optional;
import java.util.List;

public class EstudianteUI extends JFrame{
    private final EstudianteServicio servicio = new EstudianteServicio();
    private final JTextField idField = new JTextField();
    private final JTextField nombreField = new JTextField();
    private final JTextField edadField = new JTextField();
    private final DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"ID", "Nombre", "Edad"}, 0);
    private final JTable table = new JTable(tableModel);

    public EstudianteUI() {
        super("Gestión de Estudiantes");
        configurarUI();
    }

    public static void iniciar() {
        SwingUtilities.invokeLater(() -> new EstudianteUI().setVisible(true));
    }

    private void configurarUI() {
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel de entrada de datos
        JPanel panelDatos = new JPanel(new GridLayout(3, 2, 5, 5));
        panelDatos.setBorder(BorderFactory.createTitledBorder("Datos del Estudiante"));
        panelDatos.add(new JLabel("ID:"));
        panelDatos.add(idField);
        panelDatos.add(new JLabel("Nombre:"));
        panelDatos.add(nombreField);
        panelDatos.add(new JLabel("Edad:"));
        panelDatos.add(edadField);

        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        JButton agregarBtn = new JButton("Agregar");
        JButton actualizarBtn = new JButton("Actualizar");
        JButton eliminarBtn = new JButton("Eliminar");
        JButton buscarBtn = new JButton("Buscar");
        /*JButton limpiarBtn = new JButton("Limpiar");*/
        panelBotones.add(agregarBtn);
        panelBotones.add(actualizarBtn);
        panelBotones.add(eliminarBtn);
        panelBotones.add(buscarBtn);
        /*panelBotones.add(limpiarBtn);*/

        // Tabla de estudiantes
        JScrollPane scrollPane = new JScrollPane(table);
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Agregar componentes al JFrame
        add(panelDatos, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        // Eventos de botones
        agregarBtn.addActionListener(e -> {
            try {
                agregarEstudiante();
            } catch (ValidationException ex) {
                mostrarMensajeError("Error de validación: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                mostrarMensajeError("Formato incorrecto: " + ex.getMessage());
            } catch (Exception ex) {
                mostrarMensajeError("Error inesperado: " + ex.getMessage());
            }
        });

        actualizarBtn.addActionListener(e -> {
            try {
                actualizarEstudiante();
            } catch (ValidationException ex) {
                mostrarMensajeError("Error de validación: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                mostrarMensajeError("Formato incorrecto: " + ex.getMessage());
            } catch (Exception ex) {
                mostrarMensajeError("Error inesperado: " + ex.getMessage());
            }
        });
        eliminarBtn.addActionListener(e -> eliminarEstudiante());
        buscarBtn.addActionListener(e -> buscarEstudiante());
        /*limpiarBtn.addActionListener(e -> limpiarCampos());*/

        // Evento para seleccionar fila y cargar campos
        table.getSelectionModel().addListSelectionListener(e -> {
            int fila = table.getSelectedRow();
            if (fila >= 0) {
                idField.setText(table.getValueAt(fila, 0).toString());
                nombreField.setText(table.getValueAt(fila, 1).toString());
                edadField.setText(table.getValueAt(fila, 2).toString());
            }
        });

        cargarEstudiantes(); // Carga inicial
    }

    private void cargarEstudiantes() {
        tableModel.setRowCount(0); // Limpiar tabla
        List<Estudiante> estudiantes = servicio.listarEstudiantes();
        for (Estudiante e : estudiantes) {
            tableModel.addRow(new Object[]{e.getId(), e.getNombre(), e.getEdad()});
        }
    }

    private void agregarEstudiante() throws ValidationException {
        int id = Integer.parseInt(idField.getText());
        String nombre = nombreField.getText();
        int edad = Integer.parseInt(edadField.getText());

        servicio.crearEstudiante(id, nombre, edad);
        cargarEstudiantes();
        mostrarMensaje("Estudiante agregado correctamente.");
    }

    private void actualizarEstudiante() throws ValidationException {
        int id = Integer.parseInt(idField.getText());
        String nombre = nombreField.getText();
        int edad = Integer.parseInt(edadField.getText());

        if (servicio.actualizarEstudiante(id, nombre, edad)) {
            cargarEstudiantes();
            mostrarMensaje("Estudiante actualizado correctamente.");
        } else {
            mostrarMensajeError("Estudiante no encontrado.");
        }
    }

    private void eliminarEstudiante() {
        try {
            int id = Integer.parseInt(idField.getText());
            if (servicio.eliminarEstudiante(id)) {
                cargarEstudiantes();
                /*limpiarCampos();*/
                mostrarMensaje("Estudiante eliminado.");
            } else {
                mostrarMensaje("Estudiante no encontrado.");
            }
        } catch (Exception e) {
            mostrarMensaje("Error al eliminar.");
        }
    }

    private void buscarEstudiante() {
        try {
            int id = Integer.parseInt(idField.getText());
            Optional<Estudiante> est = servicio.buscarEstudiantePorId(id);
            if (est.isPresent()) {
                nombreField.setText(est.get().getNombre());
                edadField.setText(String.valueOf(est.get().getEdad()));
                mostrarMensaje("Estudiante encontrado.");
            } else {
                mostrarMensaje("Estudiante no encontrado.");
            }
        } catch (Exception e) {
            mostrarMensaje("Error en la búsqueda.");
        }
    }


    private void mostrarMensaje(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarMensajeError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}

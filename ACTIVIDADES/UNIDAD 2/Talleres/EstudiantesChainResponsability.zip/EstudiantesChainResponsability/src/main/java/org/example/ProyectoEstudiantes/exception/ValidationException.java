package org.example.ProyectoEstudiantes.exception;

public class ValidationException extends RuntimeException{
    public ValidationException(String mensaje){
        super(mensaje);
    }
}

package org.example.ProyectoEstudiantes.servicio.validator;
import org.example.ProyectoEstudiantes.exception.ValidationException;
import org.example.ProyectoEstudiantes.modelo.Estudiante;

public class EdadValidator extends AbstractEstudianteValidator{
    @Override
    protected void performValidation(Estudiante estudiante) throws ValidationException {
        if (estudiante.getEdad() < 16 || estudiante.getEdad() > 100) {
            throw new ValidationException("La edad del estudiante debe estar entre 16 y 100 años.");
        }
    }
}

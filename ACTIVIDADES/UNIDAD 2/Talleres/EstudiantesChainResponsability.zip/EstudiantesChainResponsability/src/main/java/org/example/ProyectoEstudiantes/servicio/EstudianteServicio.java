package org.example.ProyectoEstudiantes.servicio;

import org.example.ProyectoEstudiantes.modelo.Estudiante;
import org.example.ProyectoEstudiantes.repositorio.EstudianteReposiorio;
import org.example.ProyectoEstudiantes.servicio.validator.*;
import org.example.ProyectoEstudiantes.exception.ValidationException;


import java.util.List;
import java.util.Optional;

public class EstudianteServicio {
    private final EstudianteReposiorio estudianteReposiorio = new EstudianteReposiorio();
    private final EstudianteValidator validationChain;

    public EstudianteServicio() {
        IdValidator idValidator = new IdValidator();
        NombreValidator nombreValidator = new NombreValidator();
        EdadValidator edadValidator = new EdadValidator();

        idValidator.setNext(nombreValidator);
        nombreValidator.setNext(edadValidator);
        this.validationChain = idValidator;
    }

    public void crearEstudiante(int id, String nombre, int edad) throws ValidationException {
        Estudiante estudiante = new Estudiante(id, nombre, edad);
        validationChain.validate(estudiante); // Validar antes de guardar
        estudianteReposiorio.agregar(estudiante); //agregar a la lista
    }

    public List<Estudiante> listarEstudiantes() {
        return estudianteReposiorio.obtenerTodos();
    }

    public Optional<Estudiante> buscarEstudiantePorId(int id) {
        return estudianteReposiorio.buscarPorId(id);
    }

    public boolean actualizarEstudiante(int id, String nombreNuevo, int edadNueva) throws ValidationException {
        Optional<Estudiante> estudiante = estudianteReposiorio.buscarPorId(id);
        if(estudiante.isPresent()) {
            Estudiante estudianteActual = estudiante.get();
            estudianteActual.setNombre(nombreNuevo);
            estudianteActual.setEdad(edadNueva);

            validationChain.validate(estudianteActual); // Validar antes de actualizar
            return true;
        }
        return false;
    }

    public boolean eliminarEstudiante(int id) {
        return estudianteReposiorio.eliminar(id);
    }
}

package org.example.ProyectoEstudiantes.servicio.validator;
import org.example.ProyectoEstudiantes.exception.ValidationException;
import org.example.ProyectoEstudiantes.modelo.Estudiante;

public class NombreValidator extends AbstractEstudianteValidator{
    @Override
    protected void performValidation(Estudiante estudiante) throws ValidationException {
        if (estudiante.getNombre() == null || estudiante.getNombre().isEmpty()) {
            throw new ValidationException("El nombre del estudiante no puede estar vacío.");
        }
        if (estudiante.getNombre().length() > 50) {
            throw new ValidationException("El nombre del estudiante no puede exceder 50 caracteres");
        }
        if (estudiante.getNombre().length() < 3) {
            throw new ValidationException("El nombre del estudiante debe tener al menos 3 caracteres.");
        }
        if (!estudiante.getNombre().matches("[a-zA-Z ]+")) {
            throw new ValidationException("El nombre del estudiante solo puede contener letras y espacios.");
        }
    }
}
